/*
 * 
 * AP CSA Final Project - Arcade
 * Programmers: Landon Ehrhart and Kamron Gross
 * Date: 5/24/24
 * Description: An arcade simulation program that allows the user to play different mini-games
 * 
 */

 import javax.swing.JOptionPane;

    public class Arcade {

        public static void main(String[] args) {                       
            
            // Boolean that controls whether or not game is still running
            boolean playAgain = true;

        // While the user has the arcade open
        while (playAgain) {
            // Opens the main menu and prompts the user with a choice
            String welcome = JOptionPane.showInputDialog("Welcome to the Arcade! Select a mini-game you would like to play: \n" +
                                                          "Tic-Tac-Toe (1)\n" +
                                                          "Hangman (2)\n" +
                                                          "Password Game (3)\n" +
                                                          "Mr. DuBose Soundboard (4)");


            // Parses the number choice from the user selection
            int choice = Integer.parseInt(welcome);

            // Controls every possible game selection
            switch (choice)
            {
                // Tic-Tac-Toe Game
                case 1: 
                // Creates a new tictactoe object and sets playing to true
                TicTacToe game = new TicTacToe();
                boolean playingTic = true;
                while (playingTic)
                {
                    // While the game is not over
                    while (!game.isGameOver()) {
                        
                        String playerTurn = game.getCurrentTurn();
                        int slot;
                        boolean validMove = false;
                        
                        // Controls what the program does when user tries to break the game while the game is still occuring
                        while (!validMove) {
                            try 
                            {
                                // Attempt to ask for an input on the board
                                slot = Integer.parseInt(JOptionPane.showInputDialog(playerTurn + "'s turn; enter a slot number to place " + playerTurn + " in: \n\n" + game.printBoard())) - 1;
                                validMove = game.playerMove(slot);
                                
                                // If slot is already taken
                                if (!validMove) 
                                    {
                                        JOptionPane.showMessageDialog(null, "Invalid input. Slot already taken or out of range. Please choose another slot.");
                                    }
                            } 
                           
                            // If the 'cancel' button is pressed mid game
                            catch (NumberFormatException e) 
                                {
                                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number.");
                                }
                        }
                    }

                    // If there is a draw
                    JOptionPane.showMessageDialog(null, game.printBoard());
                    String winner = game.checkWinner();
                    if (winner.equals("draw")) 
                        {
                            JOptionPane.showMessageDialog(null, "It's a draw!");
                            int playChoice = JOptionPane.showConfirmDialog(null, "Do you want to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
                            if (playChoice == JOptionPane.NO_OPTION) 
                                {
                                    playingTic = false;
                                }
                            else 
                                {
                                    game = new TicTacToe();
                                    playingTic = true;
                                }
                        } 
                    
                    // If there is a winner
                    else 
                        {
                            JOptionPane.showMessageDialog(null, "Player " + winner + " wins!");
                            int playChoice = JOptionPane.showConfirmDialog(null, "Do you want to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
                            if (playChoice == JOptionPane.NO_OPTION) 
                                {
                                    playingTic = false;
                                }
                            else 
                                {
                                    game = new TicTacToe();
                                    playingTic = true;
                                }
                        }
                }
                    break;

                    // Hangman
                    case 2: 
                    
                    // Sets playing to true and winning to false 
                    boolean playing = true;
                    boolean win = false;
                    while (playing)
                    {
                        // Asks user to input the hidden word for hangman
                        String inputStr = JOptionPane.showInputDialog("Input hidden word", null);
                        Hangman hangman = new Hangman(inputStr);

                        while (true)
                        {
                            // Used to show what letters the user has
                            String str = new String(hangman.getFoundLetters());
                            
                            // Asks the user for a letter to guess
                            inputStr = JOptionPane.showInputDialog("Enter a letter to guess (Lowercase)\n" + str + "\n\n" + hangman.getMan(), null);
                            
                            // If the user has inputted too many letters and lost
                            if (hangman.getWrongGuesses() >= 6)
                            {
                                choice = JOptionPane.showConfirmDialog(null, "You lost! The word was: " + hangman.getWord() + "\nWould you like to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
                                if (choice == JOptionPane.NO_OPTION) 
                                    {
                                        playing = false;
                                        break;
                                    } 
                                else 
                                    {
                                        break;
                                    }
                            }
                            
                            else
                            {
                                // Else guess the char inputted
                                hangman.guessLetter(inputStr.charAt(0));
                            }
                            
                            // Creates an array that is used to check the found letters
                            char[] letters = hangman.getFoundLetters();
                            int check = letters.length;

                            // Sorts through the array for found letters by subtracting from the array size
                            for (int i = 0; i < letters.length; i++)
                            {
                                if (letters[i] != '_')
                                {
                                    check--;
                                }
                            }

                            // If there are no blanks in the word
                            if (check == 0)
                            {
                                win = true;
                            }

                            if (win == true)
                            {
                                // Shows the user what the word was if they won, and asks them if they want to play again
                                int playChoice = JOptionPane.showConfirmDialog(null, "You win! The word was: " + hangman.getWord() + "\nWould you like to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
                                if (playChoice == JOptionPane.NO_OPTION) 
                                {
                                    playing = false;
                                    win = false;
                                    break;
                                }
                                else 
                                {
                                    win = false;
                                    
                                }
                            } 
                        } 
                    }
                    break;

                    // Password Game
                    case 3:
                    
                    boolean playingPass = true;
                    while (playingPass)
                        {
                            // Asks the user for their initial password to start the game
                            String inputStr = JOptionPane.showInputDialog("Input your password (MAKE ONE UP)", null);
                            PasswordGame password = new PasswordGame(inputStr);

                            // While game is functioning
                            boolean passingRules = false;
                            while (!passingRules)
                                {
                                    // Continues to ask for additions to the password to fit the rules
                                    inputStr = JOptionPane.showInputDialog(password.applyRule(), password.getPass());
                                    password.setPass(inputStr);

                                    // If all the rules are passed, prints users final password
                                    if (password.applyRule().equals("1"))
                                    {
                                        JOptionPane.showMessageDialog(null, "You beat the password game! Your final password: " + password.getPass());
                                        int playChoice = JOptionPane.showConfirmDialog(null, "Do you want to play again?", "Play Again", JOptionPane.YES_NO_OPTION);
                                        if (playChoice == JOptionPane.NO_OPTION) 
                                            {
                                                playingPass = false;
                                                break;
                                            }
                                        else 
                                            {
                                                passingRules = true;
                                                playingPass = true;
                                            }
                                    }
                                }
                        }
                    break;
                    
                    // Soundboard
                    case 4:
                    Soundboard dubose = new Soundboard();

                    // While exit button is not pressed
                    while (!dubose.getExitStatus())
                        {
                            // Intentional blank
                        }
                    
                    break;   
            }
        }                 
    }
}

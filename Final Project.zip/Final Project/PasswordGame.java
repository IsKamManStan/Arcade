// Class for the password game in arcade

public class PasswordGame {
    
    // Instance variables
    private String word;

    // Constructors
    public PasswordGame(String w)
        {
            word = w.toLowerCase();
        }

    // Accessors
    public String getPass()
        {
            return word;
        }

    // Mutators
    public void setPass(String s)
        {
            word = s.toLowerCase();
        }

    public String applyRule()
        {
            // Runs the password through a series of rules to create a big password that follows all of them
            // Returns 1 when all rules are shown
            if (word.indexOf("alabama") == -1)
            {
                return "Rule 1: Password must contain Mr.Dubose's favorite state";
            }
            else if (word.indexOf("cocacola") == -1 && word.indexOf("coke") == -1)
            {
                return "Rule 2: Password must contain Mr.Dubose's favorite drink";
            }
            else if (word.indexOf("algebra2") == -1 && word.indexOf("algebratwo") == -1)
            {
                return "Rule 3: Password must contain the prerequisite to AP Comp Sci A";
            }
            else if (word.indexOf("nothing") == -1 && word.indexOf("nuthin") == -1)
            {
                return "Rule 4: Password must contain \"yall don't know ______\"";
            }
            else if (word.indexOf("fail") == -1)
            {
                return "Rule 5: Password must contain what Mr.Dubose thinks his students are going to do in his class";
            }
            else
            {
                return "1";
            }
        }
    


}

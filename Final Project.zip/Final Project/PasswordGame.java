public class PasswordGame {
    
    // Instance variables
    private String word;

    // Constructors
    public PasswordGame(String w)
        {
            word = w.toLowerCase();

        }

    // Accessors
    public String getPass()
        {
            return word;
        }

    // Mutators
    public String addToPass(String s)
        {
            return "" + s + word;
        }

    public String applyRule(String m)
        {

        }
    


}

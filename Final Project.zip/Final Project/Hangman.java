public class Hangman {
    // instance variables
    private String word;
    private char[] foundLetters;
    private int wrongGuess;
    
    // Constructor that creates the hangman object with the hidden word
    public Hangman(String w)
    {
        word = w.toLowerCase();
        wrongGuess = 0;
        foundLetters = new char[word.length()];
        for (int i = 0; i < foundLetters.length; i++)
        {
            foundLetters[i] = '_';
        }
    }

    // Accesors
    public String getWord()
    {
        return word;
    }

    public int getWrongGuesses()
    {
        return wrongGuess;
    }

    public char[] getFoundLetters()
    {
        return foundLetters;
    }

    // Mutators 
    public void setWord(String w)
    {
        word = w;
    }

    public void resetGuesses()
    {
        wrongGuess = 0;
    }

    public char[] guessLetter(char g)
    {
        boolean inWord = false;
        for (int i = 0; i < word.length(); i++)
        {
            if (g == word.charAt(i))
            {
                foundLetters[i] = word.charAt(i);
                inWord = true;
            }
        }

        if (!inWord)
        {
            wrongGuess++;
        }
        return foundLetters;
    }

    public String getMan()
    {
        if (wrongGuess == 0)
        {
            return "_______\n|\n|\n|\n|\n|\n__";   
        }
        else if (wrongGuess == 1)
        {
            return "_______\n|       O\n|\n|\n|\n|\n|\n__";
        }
        else if (wrongGuess == 2)
        {
            return "_______\n|       O\n|       |\n|       |\n|\n|\n|\n|\n|\n__";
        }
        else if (wrongGuess == 3)
        {
            return "_______\n|       O\n|     / | \n|       |\n|\n|\n|\n|\n|\n|\n__";
        }
        else if (wrongGuess == 4)
        {
            return "_______\n|       O\n|     / | \\\n|       |\n|\n|\n|\n|\n|\n|\n__";
        }
        else if (wrongGuess == 5)
        {
            return "_______\n|       O\n|     / | \\\n|       |\n|     /\n|\n|\n|\n|\n|\n__";
        }
        else if (wrongGuess == 6)
        {
            return "_______\n|       O\n|     / | \\\n|       |\n|     /  \\\n|\n|\n|\n|\n|\n__";
        }
        else 
        {
            return "You lost! The word was " + word + ", would you like to play again? (1 = yes) (0 = no)";
        }
            
    }
}  

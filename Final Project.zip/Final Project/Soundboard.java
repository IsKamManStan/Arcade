// Class for soundboard function of the arcade

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.sound.sampled.*;
import javax.swing.*;

public class Soundboard extends JFrame implements ActionListener {

    // Instance Variables
    private JButton exitButton;
    private JButton evil;
    private JButton bomboclat;
    private JButton drill;
    private boolean exit;
    private Clip clip;

    // Soundboard GUI Constructor
    public Soundboard() {
        // Create layout and buttons
        super("Mr. DuBose Soundboard");
        exit = false;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        exitButton = new JButton("Exit");
        evil = new JButton("Algebra 2");
        bomboclat = new JButton("Bomboclat");
        drill = new JButton("Bronx");

        // Add clicking capabilities
        exitButton.addActionListener(this);
        evil.addActionListener(this);
        bomboclat.addActionListener(this);
        drill.addActionListener(this);

        // Adding the buttons to the GUI
        add(evil);
        add(bomboclat);
        add(drill);
        add(exitButton);

        // Dimensions of GUI
        setSize(500, 100);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // If the buttons are clicked, play the sound and display images
    @Override
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == exitButton) 
            {
                exitThingy();
            } 
        else if (event.getSource() == evil) 
            {
                playEvil();
            } 
        else if (event.getSource() == bomboclat) 
            {
                playBomboclat();
            } 
        else if (event.getSource() == drill) 
            {
                playDrill();
            }
    }

    // Soundboard button
    public void playDrill() {
        // Check to see if exit button of image is clicked
        if (clip != null && clip.isRunning()) 
            {
                clip.stop();
            }
        // Setting up the display screen for portion of soundboard
        try 
            {
                File file = new File(
                "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuDrill.wav");
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(file);
                String imagePath = "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuDrill.jpg";
                ImageIcon imageIcon = new ImageIcon(imagePath);
                JLabel imageLabel = new JLabel(imageIcon);
                JFrame frame = new JFrame("The Bronx");

                frame.getContentPane().add(imageLabel, BorderLayout.CENTER);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();

                // Check to see if exit button of image is clicked for audio
                frame.addWindowListener(new WindowAdapter() 
                {
                    @Override
                    public void windowClosing(WindowEvent e) 
                    {
                        clip.stop();
                    }
                });
            } 
        catch (Exception e) 
            {
                System.out.println(e);
            }
    }

    // Soundboard button
    public void playBomboclat() {
        // Check to see if exit button of image is clicked 
        if (clip != null && clip.isRunning()) 
            {
                clip.stop();
            }
        // Setting up the display screen for portion of soundboard
        try 
            {
                File file = new File(
                        "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuBombaclat.wav");
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(file);
                String imagePath = "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuBombaclat.jpg";
                ImageIcon imageIcon = new ImageIcon(imagePath);
                JLabel imageLabel = new JLabel(imageIcon);
                JFrame frame = new JFrame("BOMBOCLAAAAT");

                frame.getContentPane().add(imageLabel, BorderLayout.CENTER);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();

                // Check to see if exit button of image is clicked for audio
                frame.addWindowListener(new WindowAdapter() 
                {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        clip.stop();
                    }
                });
            } 
            catch (Exception e) 
                {
                    System.out.println(e);
                }
    }

    // Soundboard button
    public void playEvil() {
        // Check to see if exit button of image is clicked 
        if (clip != null && clip.isRunning()) 
            {
                clip.stop();
            }
        // Setting up the display screen for portion of soundboard
        try 
            {
                File file = new File(
                        "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuEvil.wav");
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(file);
                String imagePath = "/Users/25lehrhart/Desktop/AP Comp Sci A/Final Project/Soundboard Utilities/DuEvil.jpg";
                ImageIcon imageIcon = new ImageIcon(imagePath);
                JLabel imageLabel = new JLabel(imageIcon);
                JFrame frame = new JFrame("You didn't pass the prerquisite for this course!!!!!");

                frame.getContentPane().add(imageLabel, BorderLayout.CENTER);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

                clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();

                 // Check to see if exit button of image is clicked for audio
                frame.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        clip.stop();
                    }
                });
            } 
            catch (Exception e) 
                {
                    System.out.println(e);
                }
    }

    // Returns whether or not exit button was pressed
    public boolean getExitStatus()
        {
            return exit;
        }

    // Exit button method
    public void exitThingy() 
        {
            exit = true;
            dispose();
        }

    // Class tester
    public static void main(String[] args) {
        new Soundboard();
    }
}
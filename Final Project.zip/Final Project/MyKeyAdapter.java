import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
import javax.swing.JFrame;


public class MyKeyAdapter extends KeyAdapter{
    @Override
    public void keyPressed(KeyEvent e) 
    {
        char direction = 'R';
        
        switch(e.getKeyCode())
        {
            case KeyEvent.VK_LEFT:
                if(direction != 'R') 
                {
                    direction = 'L';
                }
                break;
            case KeyEvent.VK_RIGHT:
                if(direction != 'L') 
                {
                    direction = 'R';
                }
                break;
            case KeyEvent.VK_UP:
                if(direction != 'D') 
                {
                    direction = 'U';
                }
                break;
            case KeyEvent.VK_DOWN:
                if(direction != 'U') 
                {
                    direction = 'D';
                }
                break;
        }
    }
}
